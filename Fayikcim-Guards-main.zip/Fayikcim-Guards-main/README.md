# Fayikcim-Guards

Herkese merhabalar!

Önceden kullandığım guard botlarını yeniden sizelere sunuyorum. Herkese iyi kodlamalar!

Bot bilgileri

guardbot1 - Sunucu koruma , sağ tık ban kick koruma , bot koruma

guardbot2 - Rol silme açma güncelleme koruma , üye rol ve isim güncelleme koruma

guardbot3 - Kanal silme açma güncelleme koruma , webhook koruma , emoji silme yükleme güncelleme koruma

ayarlar.json ve fayik.json klasörlerini doldurdukdan sonra rahatlıkla botu kullanabilirsiniz.
